using System.Windows;
using System.Windows.Controls;

namespace Conferencia
{
    // Панель администратора: фильтрация заявок, карточки, смена статуса
    public partial class AdminWindow : Window
    {
        // Используется в XAML для выпадающего списка статусов в карточке
        public List<LookupItem> Statuses { get; } = new();

        public AdminWindow()
        {
            InitializeComponent();

            try
            {
                Statuses.AddRange(Db.GetStatuses());

                var filterItems = new List<LookupItem> { new() { Id = 0, Name = "Все статусы" } };
                filterItems.AddRange(Statuses);
                statusFilter.ItemsSource = filterItems;
                statusFilter.SelectedIndex = 0;

                LoadRequests();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить данные:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadRequests()
        {
            int? statusId = statusFilter.SelectedValue is int s && s != 0 ? s : null;
            string? room = string.IsNullOrWhiteSpace(roomFilterTextBox.Text)
                ? null
                : roomFilterTextBox.Text.Trim();

            var list = Db.GetAllBookings(statusId, dateFromPicker.SelectedDate, dateToPicker.SelectedDate, room);
            RequestsItemsControl.ItemsSource = list;
            counterText.Text = list.Count == 0 ? "Заявок не найдено" : $"Найдено заявок: {list.Count}";
        }

        private void ApplyFilter_Click(object sender, RoutedEventArgs e)
        {
            try { LoadRequests(); }
            catch (Exception ex) { ShowError(ex); }
        }

        private void ResetFilter_Click(object sender, RoutedEventArgs e)
        {
            statusFilter.SelectedIndex = 0;
            dateFromPicker.SelectedDate = null;
            dateToPicker.SelectedDate = null;
            roomFilterTextBox.Text = "";
            try { LoadRequests(); }
            catch (Exception ex) { ShowError(ex); }
        }

        private void SaveStatus_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button || button.Tag is not BookingItem item) return;

            try
            {
                Db.SetStatus(item.Id, item.StatusId);
                MessageBox.Show($"Статус заявки №{item.Id} обновлён.", "Готово",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                LoadRequests();   // обновить список с учётом фильтров
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            Session.CurrentUser = null;
            new MainWindow().Show();
            Close();
        }

        private static void ShowError(Exception ex) =>
            MessageBox.Show("Ошибка:\n" + ex.Message, "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
    }
}
