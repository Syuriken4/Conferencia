namespace Conferencia
{
    // Текущий авторизованный пользователь
    public static class Session
    {
        public static UserInfo? CurrentUser { get; set; }
    }
}
