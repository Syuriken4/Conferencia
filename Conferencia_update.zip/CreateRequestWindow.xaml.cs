using System.Windows;

namespace Conferencia
{
    // Создание заявки на бронирование помещения
    public partial class CreateRequestWindow : Window
    {
        public CreateRequestWindow()
        {
            InitializeComponent();
            startDatePicker.DisplayDateStart = DateTime.Today;

            try
            {
                roomComboBox.ItemsSource = Db.GetRooms().Select(r => r.Name).ToList();
                paymentComboBox.ItemsSource = Db.GetPaymentMethods();
                paymentComboBox.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить справочники:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            var user = Session.CurrentUser;
            if (user == null) return;

            string room = roomComboBox.Text.Trim();
            if (room.Length == 0)
            {
                Warn("Укажите помещение.");
                return;
            }

            if (startDatePicker.SelectedDate is not DateTime date)
            {
                Warn("Выберите желаемую дату начала.");
                return;
            }

            if (date.Date < DateTime.Today)
            {
                Warn("Дата начала не может быть в прошлом.");
                return;
            }

            if (paymentComboBox.SelectedValue is not int paymentId)
            {
                Warn("Выберите способ оплаты.");
                return;
            }

            try
            {
                string? error = Db.CreateBooking(user.Id, room, date, paymentId);
                if (error != null)
                {
                    Warn(error);
                    return;
                }

                MessageBox.Show("Заявка отправлена. Статус: «Новая».", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                BackButton_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось отправить заявку:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            new Reviewing().Show();
            Close();
        }

        private static void Warn(string text) =>
            MessageBox.Show(text, "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
    }
}
