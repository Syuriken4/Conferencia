namespace Conferencia
{
    public class UserInfo
    {
        public int Id { get; set; }
        public string FullName { get; set; } = "";
        public string Role { get; set; } = "";   // user / admin
    }

    public class LookupItem
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
    }

    // Заявка (используется и в личном кабинете, и в админ-панели)
    public class BookingItem
    {
        public int Id { get; set; }
        public string VenueName { get; set; } = "";
        public DateTime EventDate { get; set; }
        public string PaymentMethod { get; set; } = "";
        public int StatusId { get; set; }
        public string Status { get; set; } = "";
        public string UserName { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Email { get; set; } = "";
        public string ReviewText { get; set; } = "";
        public bool HasReview { get; set; }
    }
}
