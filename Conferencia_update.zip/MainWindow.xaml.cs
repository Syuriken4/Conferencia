using System.Windows;

namespace Conferencia
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OpenRegistration_Click(object sender, RoutedEventArgs e)
        {
            var registrationWindow = new Registration();
            registrationWindow.Show();
            Close();
        }

        // Кнопка «Вход»
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string login = loginTextbox.Text.Trim();
            string password = passwordBox.Password;

            if (login.Length == 0 || password.Length == 0)
            {
                MessageBox.Show("Введите логин и пароль.", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var user = Db.Authenticate(login, password);
                if (user == null)
                {
                    MessageBox.Show("Неверный логин или пароль.", "Ошибка входа",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                Session.CurrentUser = user;

                // Администратор попадает в админ-панель, пользователь — в свои заявки
                Window next = user.Role == "admin" ? new AdminWindow() : new Reviewing();
                next.Show();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось выполнить вход:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
