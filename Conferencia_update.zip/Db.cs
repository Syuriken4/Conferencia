using Npgsql;
using NpgsqlTypes;

namespace Conferencia
{
    // Вся работа с PostgreSQL собрана в одном месте
    public static class Db
    {
        // TODO: укажите имя своей БД и пароль пользователя postgres
        private const string ConnectionString =
            "Host=localhost;Port=5432;Database=conferences;Username=postgres;Password=YOUR_PASSWORD";

        private static NpgsqlConnection Open()
        {
            var conn = new NpgsqlConnection(ConnectionString);
            conn.Open();
            return conn;
        }

        // ---------- Авторизация и регистрация ----------

        public static UserInfo? Authenticate(string login, string password)
        {
            using var conn = Open();
            using var cmd = new NpgsqlCommand(
                @"SELECT u.pk_user, u.password_hash, u.full_name, r.name
                  FROM users u
                  JOIN roles r ON r.pk_role = u.fk_role
                  WHERE u.login = @login", conn);
            cmd.Parameters.AddWithValue("login", login);

            using var rd = cmd.ExecuteReader();
            if (!rd.Read()) return null;

            string hash = rd.GetString(1);
            if (!BCrypt.Net.BCrypt.Verify(password, hash)) return null;

            return new UserInfo
            {
                Id = rd.GetInt32(0),
                FullName = rd.GetString(2),
                Role = rd.GetString(3)
            };
        }

        // Возвращает null при успехе или текст ошибки для пользователя
        public static string? RegisterUser(string login, string password, string fullName, string phone, string email)
        {
            try
            {
                using var conn = Open();
                using var cmd = new NpgsqlCommand(
                    @"INSERT INTO users (login, password_hash, full_name, phone, email)
                      VALUES (@login, @hash, @name, @phone, @email)", conn);
                cmd.Parameters.AddWithValue("login", login);
                cmd.Parameters.AddWithValue("hash", BCrypt.Net.BCrypt.HashPassword(password));
                cmd.Parameters.AddWithValue("name", fullName);
                cmd.Parameters.AddWithValue("phone", phone);
                cmd.Parameters.AddWithValue("email", email);
                cmd.ExecuteNonQuery();
                return null;
            }
            catch (PostgresException ex) when (ex.SqlState == PostgresErrorCodes.UniqueViolation)
            {
                return ex.ConstraintName == "uq_users_login"
                    ? "Этот логин уже занят"
                    : "Этот адрес электронной почты уже зарегистрирован";
            }
            catch (PostgresException ex) when (ex.SqlState == PostgresErrorCodes.CheckViolation)
            {
                return "Одно из полей заполнено в неверном формате";
            }
        }

        // ---------- Справочники ----------

        public static List<LookupItem> GetRooms() =>
            ReadLookup("SELECT pk_room, name FROM rooms ORDER BY name");

        public static List<LookupItem> GetPaymentMethods() =>
            ReadLookup("SELECT pk_payment_method, name FROM payment_methods ORDER BY pk_payment_method");

        public static List<LookupItem> GetStatuses() =>
            ReadLookup("SELECT pk_request_status, name FROM request_statuses ORDER BY pk_request_status");

        private static List<LookupItem> ReadLookup(string sql)
        {
            var list = new List<LookupItem>();
            using var conn = Open();
            using var cmd = new NpgsqlCommand(sql, conn);
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
                list.Add(new LookupItem { Id = Convert.ToInt32(rd.GetValue(0)), Name = rd.GetString(1) });
            return list;
        }

        // ---------- Заявки ----------

        // Помещение ищется по введённому названию (без учёта регистра)
        public static string? CreateBooking(int userId, string roomName, DateTime startDate, int paymentMethodId)
        {
            using var conn = Open();
            using var cmd = new NpgsqlCommand(
                @"INSERT INTO bookings (fk_user, fk_room, start_date, fk_payment_method)
                  SELECT @user, r.pk_room, @date, @pay
                  FROM rooms r
                  WHERE lower(r.name) = lower(@room)", conn);
            cmd.Parameters.AddWithValue("user", userId);
            cmd.Parameters.AddWithValue("date", DateOnly.FromDateTime(startDate));
            cmd.Parameters.AddWithValue("pay", paymentMethodId);
            cmd.Parameters.AddWithValue("room", roomName.Trim());

            return cmd.ExecuteNonQuery() == 0 ? "Помещение с таким названием не найдено" : null;
        }

        public static List<BookingItem> GetUserBookings(int userId)
        {
            using var conn = Open();
            using var cmd = new NpgsqlCommand(
                BookingSelect + " WHERE pk_user = @user ORDER BY created_at DESC", conn);
            cmd.Parameters.AddWithValue("user", userId);
            return ReadBookings(cmd);
        }

        // Любой фильтр может быть null
        public static List<BookingItem> GetAllBookings(int? statusId, DateTime? dateFrom, DateTime? dateTo, string? room)
        {
            using var conn = Open();
            using var cmd = new NpgsqlCommand(
                BookingSelect + @"
                  WHERE (@status::smallint IS NULL OR pk_request_status = @status)
                    AND (@dfrom::date IS NULL OR start_date >= @dfrom)
                    AND (@dto::date   IS NULL OR start_date <= @dto)
                    AND (@room::text  IS NULL OR room ILIKE '%' || @room || '%')
                  ORDER BY created_at DESC", conn);

            cmd.Parameters.Add(new NpgsqlParameter("status", NpgsqlDbType.Smallint)
                { Value = (object?)statusId ?? DBNull.Value });
            cmd.Parameters.Add(new NpgsqlParameter("dfrom", NpgsqlDbType.Date)
                { Value = (object?)dateFrom?.Date ?? DBNull.Value });
            cmd.Parameters.Add(new NpgsqlParameter("dto", NpgsqlDbType.Date)
                { Value = (object?)dateTo?.Date ?? DBNull.Value });
            cmd.Parameters.Add(new NpgsqlParameter("room", NpgsqlDbType.Text)
                { Value = (object?)room ?? DBNull.Value });

            return ReadBookings(cmd);
        }

        public static void SetStatus(int bookingId, int statusId)
        {
            using var conn = Open();
            using var cmd = new NpgsqlCommand(
                "UPDATE bookings SET fk_request_status = @status WHERE pk_booking = @id", conn);
            cmd.Parameters.Add(new NpgsqlParameter("status", NpgsqlDbType.Smallint) { Value = (short)statusId });
            cmd.Parameters.AddWithValue("id", bookingId);
            cmd.ExecuteNonQuery();
        }

        // ---------- Отзывы ----------

        // Статус «Завершено» проверяет триггер в БД
        public static string? AddReview(int bookingId, int userId, string text)
        {
            try
            {
                using var conn = Open();
                using var cmd = new NpgsqlCommand(
                    @"INSERT INTO reviews (fk_booking, text)
                      SELECT b.pk_booking, @text
                      FROM bookings b
                      WHERE b.pk_booking = @id AND b.fk_user = @user", conn);
                cmd.Parameters.AddWithValue("text", text);
                cmd.Parameters.AddWithValue("id", bookingId);
                cmd.Parameters.AddWithValue("user", userId);

                return cmd.ExecuteNonQuery() == 0 ? "Заявка не найдена" : null;
            }
            catch (PostgresException ex) when (ex.SqlState == PostgresErrorCodes.UniqueViolation)
            {
                return "Отзыв к этой заявке уже оставлен";
            }
            catch (PostgresException ex) when (ex.SqlState == PostgresErrorCodes.RaiseException)
            {
                return ex.MessageText;   // «Отзыв можно оставить только после завершения мероприятия»
            }
        }

        // ---------- Вспомогательное ----------

        private const string BookingSelect =
            @"SELECT pk_booking, room, start_date, payment_method, pk_request_status, status,
                     full_name, phone, email, pk_review, review_text
              FROM v_bookings_full";

        private static List<BookingItem> ReadBookings(NpgsqlCommand cmd)
        {
            var list = new List<BookingItem>();
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                list.Add(new BookingItem
                {
                    Id = rd.GetInt32(0),
                    VenueName = rd.GetString(1),
                    EventDate = rd.GetDateTime(2),
                    PaymentMethod = rd.GetString(3),
                    StatusId = Convert.ToInt32(rd.GetValue(4)),
                    Status = rd.GetString(5),
                    UserName = rd.GetString(6),
                    Phone = rd.GetString(7),
                    Email = rd.GetString(8),
                    HasReview = !rd.IsDBNull(9),
                    ReviewText = rd.IsDBNull(10) ? "" : rd.GetString(10)
                });
            }
            return list;
        }
    }
}
