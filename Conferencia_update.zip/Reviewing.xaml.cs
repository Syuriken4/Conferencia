using System.Windows;
using System.Windows.Controls;

namespace Conferencia
{
    // Личный кабинет: заявки текущего пользователя и отзывы
    public partial class Reviewing : Window
    {
        public Reviewing()
        {
            InitializeComponent();
            LoadUserRequests();
        }

        private void LoadUserRequests()
        {
            var user = Session.CurrentUser;
            if (user == null) return;

            try
            {
                RequestsItemsControl.ItemsSource = Db.GetUserBookings(user.Id);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить заявки:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveReviewButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button || button.Tag is not BookingItem request) return;
            var user = Session.CurrentUser;
            if (user == null) return;

            if (request.HasReview)
            {
                MessageBox.Show("Отзыв к этой заявке уже оставлен.", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (string.IsNullOrWhiteSpace(request.ReviewText))
            {
                MessageBox.Show("Пожалуйста, введите текст отзыва перед сохранением.",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                string? error = Db.AddReview(request.Id, user.Id, request.ReviewText.Trim());
                if (error != null)
                {
                    MessageBox.Show(error, "Не удалось сохранить отзыв",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                MessageBox.Show($"Отзыв для мероприятия в помещении «{request.VenueName}» успешно сохранен!",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUserRequests();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении отзыва:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void NewRequestButton_Click(object sender, RoutedEventArgs e)
        {
            new CreateRequestWindow().Show();
            Close();
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            Session.CurrentUser = null;
            new MainWindow().Show();
            Close();
        }
    }
}
